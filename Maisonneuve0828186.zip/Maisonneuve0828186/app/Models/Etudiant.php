<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Etudiant extends Model
{
    use HasFactory;

    protected $fillable = ['etudiant_nom', 'etudiant_adresse', 'etudiant_phone','etudiant_email','etudiant_anniversaire','ville_id'];

    public function etudiantHasVille(){
        return $this->hasOne('App\Models\villes', 'id', 'ville_id');
    }

    public function selectBlog($id)
    {
        $query = BlogPost::Select('body', 'ville_nom')
        ->JOIN('villes', 'etudiants.ville_id', '=', 'villes.id')
        ->WHERE("villes.id", $id)
            ->get();
        return $query;
    }

}

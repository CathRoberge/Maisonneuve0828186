@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-12 pt-2">
            <a href="{{ route('etudiant')}}" class="btn btn-primary btn-sm">Retourner</a>
            <hr>
            <h1 class="display-one">{{ ucfirst($etudiant->etudiant_nom) }}</h1>
            <p>{!! $etudiant->etudiant_addresse !!}</p>
            <p>Adresse: {{ $etudiant->etudiant_adresse }}</p>
            <p>Téléphone: {{ $etudiant->etudiant_phone }}</p>
            <p>Email: {{ $etudiant->etudiant_email }}</p>
            <p>Anniversaire: {{ $etudiant->etudiant_anniversaire }}</p>
            <hr>
            <a href="{{route('etudiant.edit', $etudiant->id)}}" class="btn btn-outline-primary">Modifier l'étudiant</a>
            <hr>
            <form method="post">
                @csrf
                @method('DELETE')
                <button class="btn btn-outline-danger">Supprimer</button>
            </form>
        </div>
    </div>
</div>
@endsection

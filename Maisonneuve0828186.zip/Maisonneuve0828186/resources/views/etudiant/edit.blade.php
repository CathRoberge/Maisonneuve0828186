@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-12 pt-2">
            <h1 class="display-4">Modifier un message</h1>
            <div class="card mt-5">
                <div class="card-header">
                    Message
                </div>
                <div class="card-body">
                    <form method="post">
                        @csrf
                        @method('PUT')
                        <div class="row">
                            <div class="control-group">
                                <label for="nom">Nom complet</label>
                                <input type="text" name="nom" id="nom" class="form-control mt-2" value="{{$etudiant->etudiant_nom}}">
                                <label for="addresse">Addresse</label>
                                <input type="text" name="addresse" id="addresse" class="form-control mt-2" value="{{$etudiant->etudiant_addresse}}">
                                <label for="phone">Téléphone</label>
                                <input type="text" name="phone" id="phone" class="form-control mt-2" value="{{$etudiant->etudiant_phone}}">
                                <label for="email">Email</label>
                                <input type="text" name="email" id="email" class="form-control mt-2" value="{{$etudiant->etudiant_email}}">
                                <label for="anniversaire">Date d'anniversaire</label>
                                <input type="text" name="anniversaire" id="anniversaire" class="form-control mt-2" value="{{$etudiant->etudiant_anniversaire}}">
                                <div class="control-group">

                                    <input type="submit" class="btn btn-success mt-2" value="Envoyer">
                                </div>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

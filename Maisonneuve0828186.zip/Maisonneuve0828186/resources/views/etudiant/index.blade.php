@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-12 pt-2">
            <div class="row">
                <div class="col-8">
                    <h1 class="display-one">Collège Maisonneuve Social</h1>
                    <p>Bonne lecture</p>
                </div>
                <div class="col-4">
                    <a href="{{ route('etudiant.create')}}" class="btn btn-primary btn-sm">Ajouter un étudiant</a>
                </div>
            </div>
            <table>
                @forelse($etudiants as $etudiant)
                <tr>
                    <th>
                        <a href="{{ route('etudiant.show', $etudiant->id)}}">{{ ucfirst($etudiant->etudiant_nom)}}</a>
                    </th>
                    <th>
                        <a href="{{ route('etudiant.edit', $etudiant->id)}}">Modifier</a>
                    </th>
                    <th>
                        <a href="{{ route('etudiant.delete', $etudiant->id)}}">Supprimer</a>
                    </th>
                </tr>
                @empty
                <li class="text-warning">Aucun article disponible</li>
                @endforelse
            </table>
        </div>
    </div>
</div>
@endsection

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12 pt-2">
            <div class="row">
                <div class="col-8">
                    <h1 class="display-one">Collège Maisonneuve Social</h1>
                    <p>Bonne lecture</p>
                </div>
                <div class="col-4">
                    <a href="<?php echo e(route('etudiant.create')); ?>" class="btn btn-primary btn-sm">Ajouter un étudiant</a>
                </div>
            </div>
            <table>
                <?php $__empty_1 = true; $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th>
                        <a href="<?php echo e(route('etudiant.show', $etudiant->id)); ?>"><?php echo e(ucfirst($etudiant->etudiant_nom)); ?></a>
                    </th>
                    <th>
                        <a href="<?php echo e(route('etudiant.edit', $etudiant->id)); ?>">Modifier</a>
                    </th>
                    <th>
                        <a href="<?php echo e(route('etudiant.delete', $etudiant->id)); ?>">Supprimer</a>
                    </th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="text-warning">Aucun article disponible</li>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\ete2022\cadriciel\Maisonneuve0828186\resources\views/etudiant/index.blade.php ENDPATH**/ ?>
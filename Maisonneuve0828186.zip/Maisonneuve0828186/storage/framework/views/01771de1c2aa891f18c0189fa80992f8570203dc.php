<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12 pt-2">
            <h1 class="display-4">Ajouter un nouvel étudiant</h1>
            <div class="card mt-5">
                <div class="card-header">
                    Nouveau Message
                </div>
                <div class="card-body">
                    <form method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="control-group">
                                <label for="title">Titre</label>
                                <input type="text" name="title" id="title" class="form-control mt-2">
                            </div>
                            <div class="control-group">
                                <label for="nom">Nom complet</label>
                                <input type="text" name="etudiant_nom" id="etudiant_nom" class="form-control mt-2">
                                <label for="addresse">Addresse</label>
                                <input type="text" name="etudiant_addresse" id="etudiant_addresse" class="form-control mt-2">
                                <label for="phone">Téléphone</label>
                                <input type="text" name="etudiant_phone" id="etudiant_phone" class="form-control mt-2">
                                <label for="email">Email</label>
                                <input type="text" name="etudiant_email" id="etudiant_email" class="form-control mt-2">
                                <label for="anniversaire">Date d'anniversaire</label>
                                <input type="date" name="etudiant_anniversaire" id="etudiant_anniversaire" class="form-control mt-2">
                            </div>
                            <div class="control-group">

                                <input type="submit" class="btn btn-success mt-2" value="Envoyer">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\ete2022\cadriciel\Maisonneuve0828186\resources\views/etudiant/create.blade.php ENDPATH**/ ?>
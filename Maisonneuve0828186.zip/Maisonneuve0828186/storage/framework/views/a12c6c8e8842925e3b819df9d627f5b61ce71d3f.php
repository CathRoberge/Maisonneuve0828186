<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12 pt-2">
            <a href="<?php echo e(route('etudiant')); ?>" class="btn btn-primary btn-sm">Retourner</a>
            <hr>
            <h1 class="display-one"><?php echo e(ucfirst($etudiant->etudiant_nom)); ?></h1>
            <p><?php echo $etudiant->etudiant_addresse; ?></p>
            <p>Adresse: <?php echo e($etudiant->etudiant_adresse); ?></p>
            <p>Téléphone: <?php echo e($etudiant->etudiant_phone); ?></p>
            <p>Email: <?php echo e($etudiant->etudiant_email); ?></p>
            <p>Anniversaire: <?php echo e($etudiant->etudiant_anniversaire); ?></p>
            <hr>
            <a href="<?php echo e(route('etudiant.edit', $etudiant->id)); ?>" class="btn btn-outline-primary">Modifier l'étudiant</a>
            <hr>
            <form method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-outline-danger">Supprimer</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\ete2022\cadriciel\Maisonneuve0828186\resources\views/etudiant/show.blade.php ENDPATH**/ ?>